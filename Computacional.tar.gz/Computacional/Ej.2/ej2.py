# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 18:27:00 2017

@author: dran
"""

import numpy as np
import matplotlib.pyplot as plt

Pinf_L100 = np.loadtxt("Pinf_100.txt")
Pinf_L32 = np.loadtxt("Pinf_32.txt")
Pinf_L64 = np.loadtxt("Pinf_64.txt")


p = []
k=0;
for i in range(100):
    p.append(k)    
    k=k+1/np.size(Pinf_L100)
    
plt.plot(p,Pinf_L100,'-ro', linewidth=1.8)
plt.title('P infinito para L = 100')
plt.xlabel('p')
plt.ylabel('P inf')
plt.show()    

plt.plot(p,Pinf_L32,'-ro', linewidth=1.8)
plt.title('P infinito para L = 32')
plt.xlabel('p')
plt.ylabel('P inf')
plt.show()    

plt.plot(p,Pinf_L64,'-ro', linewidth=1.8)
plt.title('P infinito para L = 64')
plt.xlabel('p')
plt.ylabel('P inf')
plt.show()    