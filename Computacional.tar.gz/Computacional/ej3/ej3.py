# -*- coding: utf-8 -*-
"""
Created on Wed Apr 19 14:22:44 2017

@author: alumno
"""
import numpy as np
import matplotlib.pyplot as plt

Mperc = np.loadtxt("M_perc.txt")

L = []
k=4;
for i in range(128):
    L.append(k)    
    k=k+1

X = np.polyfit(np.log(L),np.log(Mperc),1)

D = X[0]  # D = Dimensión fractal.

plt.figure(1)    
plt.plot(L,Mperc,'-ro', linewidth=1.8)
plt.title('Masa del cluster percolante en p = pc = 0.5927')
plt.xlabel('L')
plt.ylabel('Masa cluster percolante')

plt.figure(2)
plt.plot(np.log(L),np.log(Mperc),'-ro', linewidth=1.8)
plt.title('Masa del cluster percolapnte en p = pc = 0.5927')
plt.xlabel('log(L)')
plt.ylabel('log(M_percolante)')

plt.show()  

