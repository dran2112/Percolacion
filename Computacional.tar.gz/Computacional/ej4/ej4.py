# -*- coding: utf-8 -*-
"""
Created on Thu Apr 20 21:28:49 2017

@author: dran
"""

import numpy as np
import matplotlib.pyplot as plt
import scipy.special as sc

Pc = 0.592652555667
Tau = 2.05
q0 = Pc/(sc.zeta(Tau-1,1))

ns_25= np.loadtxt("ns_s25.txt")
ns_30= np.loadtxt("ns_s30.txt")
ns_40= np.loadtxt("ns_s40.txt")

p = np.linspace(0.3,0.9,100)

plt.figure(1)    
plt.plot(p,ns_25*(25**Tau)/q0,'-ro', linewidth=1.8)
plt.plot(p,ns_30*(30**Tau)/q0,'-bo', linewidth=1.8)
plt.plot(p,ns_40*(40**Tau)/q0,'-bo', linewidth=1.8)

plt.xlabel('p')
plt.ylabel('ns(p)')

plt.show()  