# -*- coding: utf-8 -*-
"""
Created on Sat Apr 15 12:05:43 2017

@author: dran
"""
import numpy as np
import scipy.special as sc
import matplotlib.pyplot as plt

ns_p05_L64 = np.loadtxt("ns_p0,5_L64.txt")
ns_p06_L64 = np.loadtxt("ns_p0,6_L64.txt")
ns_p07_L64 = np.loadtxt("ns_p0,7_L64.txt")
ns_p04_L64 = np.loadtxt("ns_p0,4_L64.txt")
ns_p061_L64 = np.loadtxt("ns_p0,61_L64.txt")

ns_p06_L128 = np.loadtxt("ns_p0,6_L128.txt")

#s = np.linspace(1,np.size(ns_p061_L64),np.size(ns_p061_L64))
s = np.linspace(1,np.size(ns_p06_L128),np.size(ns_p06_L128))

Pc_L128 = 0.592652555667
Tau_ini = 2.05
q0 = Pc_L128/(sc.zeta(Tau_ini-1,1))

y = ns_p06_L128/q0
y = np.log(y)
x = np.log(s)

def Chi2(x,y,Tau):
    Chi = 0
    for k in range(np.size(y)):    
        Chi = Chi + (y[k] - (Tau)*x[k])**2

    return Chi    

JI2 = []
T = []
Tau = 3

for k in range(60):
    JI2.append(Chi2(x,y,Tau))
    T.append(Tau)
    Tau = Tau - 1/20

plt.plot(T,JI2, 'ro-')

figure(6)
plt.plot(np.log(s),np.log(ns_p06_L128),'ro')
xlabel('log(s)')
ylabel('log(ns(p))')
plt.title('p = 0.6;  L = 128')

figure(1)
plt.plot(np.log(s),np.log(ns_p05_L64),'ro')
xlabel('log(s)')
ylabel('log(ns(p))')
plt.title('p = 0.5;  L = 64')

figure(2)
plt.plot(np.log(s),np.log(ns_p06_L64),'ro')
xlabel('log(s)')
ylabel('log(ns(p))')
plt.title('p = 0.6;  L = 64')

figure(3)
plt.plot(np.log(s),np.log(ns_p07_L64),'ro')
xlabel('log(s)')
ylabel('log(ns(p))')
plt.title('p = 0.7;  L = 64')

figure(4)
plt.plot(np.log(s),np.log(ns_p04_L64),'ro')
xlabel('log(s)')
ylabel('log(ns(p))')
plt.title('p = 0.4;  L = 64')

figure(5)
plt.plot(np.log(s),np.log(ns_p061_L64),'ro')
xlabel('log(s)')
ylabel('log(ns(p))')
plt.title('p = 0.61;  L = 64')
